# %%
import numpy as np
import matplotlib.pyplot as plt
from typing import List, Tuple
from scipy.optimize import minimize
from scipy.optimize import curve_fit

# Larger fonts for all figures
plt.rcParams["axes.labelsize"] = 16
plt.rcParams["axes.titlesize"] = 18
plt.rcParams["xtick.labelsize"] = 14
plt.rcParams["ytick.labelsize"] = 14
plt.rcParams["legend.fontsize"] = 14

#%%
def single_exp_decay(t: np.ndarray, amp: float, tau: float) -> np.ndarray:
    """Single exponential decay without offset
    
    Args:
        t (array): Time points
        amp (float): Amplitude of the decay
        tau (float): Time constant of the decay
        
    Returns:
        array: Exponential decay values
    """
    return amp * np.exp(-t/tau)


def sequential_exp_fit(
    t: np.ndarray, 
    y: np.ndarray, 
    start_times: List[float], 
    fixed_taus: List[float]=None,
    a_dc: float=None,
    verbose: bool=True,
    ) -> Tuple[List[Tuple[float, float]], float, np.ndarray]:
    """
    Fit multiple exponentials sequentially by:
    1. First fit a constant term from the tail of the data
    2. Fit the longest time constant using the latter part of the data
    3. Subtract the fit
    4. Repeat for faster components
    
    Args:
        t (array): Time points in nanoseconds
        y (array): Data points (normalized amplitude)
        start_times (list): List of times (same units as t). For each component i, data with t >= start_times[i]
                            is used to fit that exponential. In descending order: first (slow) from later time,
                            then next from earlier time, e.g. [500, 100] ns.
        fixed_taus (list, optional): Fixed tau values for each exponential component. 
                                   If provided, only amplitudes are fitted, taus are constrained.
                                   Must have same length as start_times.
        a_dc (float, optional): Fixed constant term. If provided, the constant term is not fitted.
        verbose (bool): Whether to print detailed fitting information   
        
    Returns:
        tuple: (components, a_dc, residual) where:
            - components: List of (amplitude, tau) pairs for each fitted component
            - a_dc: Fitted constant term or the fixed constant term
            - residual: Residual after subtracting all components
    """
    
    components = []  # List to store (amplitude, tau) pairs
    t_offset = t - t[0]  # Make time start at 0
    
    # Find the flat region in the tail by looking at local variance
    window = max(5, len(y) // 20)  # Window size by dividing signal into 20 equal pieces or at least 5 points
    rolling_var = np.array([np.var(y[i:i+window]) for i in range(len(y)-window)])
    # Find where variance drops below threshold, indicating flat region
    var_threshold = np.mean(rolling_var) * 0.1  # 10% of mean variance
    if a_dc is None:
        try:
            flat_start = np.where(rolling_var < var_threshold)[0][-1]
            # Use the flat region to estimate constant term
            a_dc = np.mean(y[flat_start:])
        except IndexError:
            print("No flat region found, using last point of the signal as constant term")
            a_dc = y[-1]

    if verbose:
        print(f"\nFitted constant term: {a_dc:.3e}")
    
    y_residual = y.copy() - a_dc
    
    min_points_for_fit = 3  # curve_fit needs several points to fit amplitude and tau
    for i, t_start in enumerate(start_times):
        # Index of first point where t >= t_start (same units as t, e.g. ns)
        start_idx = np.searchsorted(t, t_start, side='left')
        start_idx = min(start_idx, len(t) - 1)  # ensure we have at least one point
        n_points = len(t) - start_idx
        if n_points < min_points_for_fit:
            if verbose:
                print(f"\nSkipping component {i+1}: only {n_points} point(s) with t >= {t_start:.1f} ns (need at least {min_points_for_fit}). Use a smaller start time (e.g. t_max for the last component means almost no data).")
            break
        if verbose:
            print(f"\nFitting component {i+1} using data from t >= {t_start:.1f} ns (first index t = {t[start_idx]:.1f} ns, {n_points} points)")
        
        # Fit current component
        try:
            # Prepare fitting parameters based on whether tau is fixed
            if fixed_taus is not None:
                # Use fixed tau - only fit amplitude using lambda
                tau_fixed = fixed_taus[i]
                p0 = [y_residual[start_idx]]  # Only amplitude initial guess
                if verbose:
                    print(f"Using fixed tau = {tau_fixed:.3f} ns")
                
                # Perform the fit on the current interval
                t_fit = t_offset[start_idx:]
                y_fit = y_residual[start_idx:]
                popt, _ = curve_fit(lambda t, amp: single_exp_decay(t, amp, tau_fixed), t_fit, y_fit, p0=p0)
                
                # Store the components
                amp = popt[0]
                tau = tau_fixed
            else:
                # Fit both amplitude and tau (original behavior)
                p0 = [
                    y_residual[start_idx],  # amplitude
                    t_offset[start_idx] / 3  # tau
                ]
                
                # Set bounds for the fit
                bounds = (
                    [-np.inf, 0.1],  # lower bounds: amplitude can be negative, tau must be positive (0.1 ns is arbitrary)
                    [np.inf, np.inf]  # upper bounds
                )
                
                # Perform the fit on the current interval
                t_fit = t_offset[start_idx:]
                y_fit = y_residual[start_idx:]
                popt, _ = curve_fit(single_exp_decay, t_fit, y_fit, p0=p0, bounds=bounds)
                
                # Store the components
                amp, tau = popt
            
            components.append((amp, tau))
            if verbose:
                tau_status = "(fixed)" if fixed_taus is not None else ""
                print(f"Found component: amplitude = {amp:.3e}, tau = {tau:.3f} ns {tau_status}")
            
            # Subtract this component from the entire signal
            y_residual -= amp * np.exp(-t_offset/tau)
            
        except (RuntimeError, ValueError) as e:
            if verbose:
                print(f"Warning: Fitting failed for component {i+1}: {e}")
            break
    
    return components, a_dc, y_residual


def optimize_start_times(t, y, base_times, bounds_scale=0.5, fixed_taus=None, a_dc=None, verbose=True):
    """
    Optimize the start_times by minimizing the RMS between the data and the fitted sum
    of exponentials using scipy.optimize.minimize.

    Args:
        t (array): Time points in nanoseconds
        y (array): Data points (normalized amplitude)
        base_times (list): Initial guess for start times (same units as t, e.g. ns).
                           For each component, data with t >= start_time is used. Descending order
                           (first = slow = later time, e.g. [500, 100] ns).
        bounds_scale (float): Scale factor for bounds around base times (0.5 means ±50%)
        fixed_taus (list, optional): Fixed tau values for each exponential component.
                                   If provided, only amplitudes are fitted, taus are constrained.
                                   Must have same length as base_times.
        a_dc (float, optional): Constant term. If not provided, the constant term is fitted from
                                the tail of the data.
        verbose (bool): Whether to print detailed fitting information

    Returns:
        tuple: (success, best_times, best_components, best_dc, best_rms)
    """
    # Validate fixed_taus parameter
    if fixed_taus is not None:
        if len(fixed_taus) != len(base_times):
            raise ValueError("fixed_taus must have the same length as base_times")
        if any(tau <= 0 for tau in fixed_taus):
            raise ValueError("All fixed_taus values must be positive")

    def objective(x):
        """
        Objective function to minimize: RMS between the data and the fitted sum of
        exponentials. x are start times (same units as t).
        """
        # Ensure times are in descending order (first = slow = later time, same as original fractions)
        if not np.all(np.diff(x) < 0):
            return 1e6  # Return large value if constraint is violated
        components, _, residual = sequential_exp_fit(t, y, x.tolist(), fixed_taus=fixed_taus, a_dc=a_dc, verbose=verbose)
        if len(components) == len(base_times):
            current_rms = np.sqrt(np.mean(residual**2))
        else:
            current_rms = 1e6  # Return large value if fitting fails
        return current_rms

    # Bounds: ±bounds_scale around base times, clipped to [t[0], t[-1]]
    t_min, t_max = float(t[0]), float(t[-1])
    bounds = []
    for base in base_times:
        min_val = max(t_min, base * (1 - bounds_scale))
        max_val = min(t_max, base * (1 + bounds_scale))
        bounds.append((min_val, max_val))

    print("\nOptimizing start_times using scipy.optimize.minimize...")
    print(f"Initial values (ns): {[f'{t:.1f}' for t in base_times]}")
    print(f"Bounds: ±{bounds_scale*100}% around initial values, clipped to [{t_min:.1f}, {t_max:.1f}] ns")

    # Run optimization
    result = minimize(
        objective,
        x0=np.array(base_times, dtype=float),
        bounds=bounds,
        method='Nelder-Mead',  # This method works well for non-smooth functions
        options={'disp': True, 'maxiter': 200}
    )

    # Get final results
    best_times = result.x
    if result.success:
        components, a_dc, best_residual = sequential_exp_fit(t, y, best_times.tolist(), fixed_taus=fixed_taus, a_dc=a_dc, verbose=False)
        best_rms = np.sqrt(np.mean(best_residual**2))
        print("\nOptimization successful!")
        print(f"Initial times (ns): {[f'{t:.1f}' for t in base_times]}")
        print(f"Optimized times (ns): {[f'{t:.1f}' for t in best_times]}")
        if fixed_taus is not None:
            print(f"Fixed taus: {[f'{tau:.3f} ns' for tau in fixed_taus]}")
        print(f"Final RMS: {best_rms:.3e}")
        print(f"Number of iterations: {result.nit}")
    else:
        print("\nOptimization failed. Using initial values.")
        best_times = np.array(base_times, dtype=float)
        components, a_dc, best_residual = sequential_exp_fit(t, y, best_times.tolist(), fixed_taus=fixed_taus, a_dc=a_dc, verbose=False)
        best_rms = np.sqrt(np.mean(best_residual**2))

    components = [(amp * np.exp(t[0] / tau), tau) for amp, tau in components]
    print(components)
    return result.success, best_times, components, a_dc, best_rms

def plot_fit(t_data: np.ndarray, y_data: np.ndarray, components: List[Tuple[float, float]], a_dc: float):
    """Plot exponential fit results with both linear and log scales.
    
    Args:
        t_data (np.ndarray): Time points in nanoseconds
        y_data (np.ndarray): Measured flux response data
        components (List[Tuple[float, float]]): List of (amplitude, tau) pairs for each fitted component
        a_dc (float): Constant term

    Returns:
        tuple: (fig, axs) where:
            - fig: Figure object
            - axs: List of axes objects
    """

    fit_text = f'a_dc = {a_dc:.3f}\n'
    y_fit = np.ones_like(t_data, dtype=float) * a_dc
    for i, (amp, tau) in enumerate(components):
        y_fit += amp * np.exp(-t_data/tau)
        fit_text += f'a{i+1} = {amp:.3f}, τ{i+1} = {tau:.0f}ns\n'

    fig, axs = plt.subplots(1, 2, figsize=(12, 5))

    # First subplot - linear scale
    axs[0].plot(t_data, y_data, label='Data')
    axs[0].plot(t_data, y_fit, label='Fit')
    axs[0].text(0.98, 0.5, fit_text, transform=axs[0].transAxes, fontsize=10,
             horizontalalignment='right', verticalalignment='center')
    axs[0].set_xlabel('Time (ns)')
    axs[0].set_ylabel('Flux Response')
    axs[0].legend()
    axs[0].grid(True)
    axs[0].ticklabel_format(axis='x', style='sci', scilimits=(0,0))

    # Second subplot - log scale 
    axs[1].plot(t_data, y_data, label='Data')
    axs[1].plot(t_data, y_fit, label='Fit')
    axs[1].text(0.98, 0.5, fit_text, transform=axs[1].transAxes, fontsize=10,
             horizontalalignment='right', verticalalignment='center')
    axs[1].set_xlabel('Time (ns)')
    axs[1].set_ylabel('Flux Response')
    axs[1].set_xscale('log')
    axs[1].legend(loc='best')
    axs[1].grid(True)

    fig.tight_layout()

    return fig, axs

# %% load data
data = np.loadtxt("step_response_with_and_without_bias_tee.csv", delimiter=",")

#%%
t_raw = data[:, 0] * 1e9 # convert to ns
y_raw_without_biastee = data[:, 1]
y_raw_with_biastee = data[:, 2]

plt.figure(figsize=(10, 6))
plt.semilogx(t_raw, y_raw_without_biastee, label="without bias tee")
plt.semilogx(t_raw, y_raw_with_biastee, label="with bias tee")
plt.xlabel("Time [ns]")
plt.ylabel("Voltage [V]")
plt.title("Step response with and without bias tee")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()


mask_t1 = (t_raw > 10) & (t_raw < 1e4)
mask_v1 = y_raw_with_biastee > 0
mask = mask_t1 & mask_v1 

t_data = t_raw[mask]
y_data_without_biastee = y_raw_without_biastee[mask]
y_data_with_biastee = y_raw_with_biastee[mask]

# Resampling
dt_ns = 5
t_data_interp = np.arange(t_data.min(), t_data.max(), dt_ns)
y_data_without_biastee_interp = np.interp(t_data_interp, t_data, y_data_without_biastee)
y_data_with_biastee_interp = np.interp(t_data_interp, t_data, y_data_with_biastee)

plt.figure(figsize=(10, 6))
plt.semilogx(t_data_interp, y_data_without_biastee_interp, label="without bias tee")
plt.semilogx(t_data_interp, y_data_with_biastee_interp, label="with bias tee")
plt.xlabel("Time [ns]")
plt.ylabel("Voltage [V]")
plt.title("Step response with and without bias tee")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()

# %%
# fit data (base_times in ns: data from t >= each time is used for that component)
t_min, t_max = t_data_interp.min(), t_data_interp.max()
fitting_base_times = [t_min]
success, best_times, components, a_dc, best_rms = optimize_start_times(t_data_interp, y_data_with_biastee_interp, fitting_base_times)

# plot data and fit
fig, axs = plot_fit(t_data_interp, y_data_with_biastee_interp, components, a_dc)

# parameters to update in config
A_list = [component[0] for component in components]
tau_list = [component[1] for component in components]
exponential_filter = list(zip(A_list, tau_list))